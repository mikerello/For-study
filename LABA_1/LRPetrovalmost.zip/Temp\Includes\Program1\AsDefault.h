#ifndef _PROGRAM1_DEFAULT_1433682178
#define _PROGRAM1_DEFAULT_1433682178
#include "../AsDefault.h"
#include <bur/plctypes.h>
#include <bur/plc.h>
#include <typesTYP.h>
#include <variablesVAR.h>
#endif
